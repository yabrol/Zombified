/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package zombiecrushsaga.events;

/**
 *
 * @author Yukti
 */
public class PowerUpHandler {
  
}
